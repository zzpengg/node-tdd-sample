export default function add(x,y){
  console.log("add ok");
  return x + y;
}
